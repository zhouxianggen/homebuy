# -*- coding: utf-8 -*-
#!/usr/bin/env python

__author__  = "xianggen.zhou"
__date__    = "2016-03-23"

OK = '0'
SERVER_MYSQL_ERROR = '1'
NPUT_DATA_ERROR = '2'
SERVER_MYSQL_DATA_ERROR = '3'
